import React, { Component } from 'react';
import { ActivityIndicator, FlatList, Text, View } from 'react-native';
import { LoginRequest } from '../dto/LoginRequest';
import { LoginResponse } from '../dto/LoginResponse';

export default class ConnectApi extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data: LoginResponse,
            isLoading: true
        };
    }

    async getMovies() {
        try {
            const response = await fetch('http://mobilepricechecker-sapi.us-e2.cloudhub.io/api/login', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'client_id': "1",
                    'client_secret': "7"
                },
                body: JSON.stringify({
                    "userName": "Wright@gmail.in",
                    "password": "messi1234"
                })
            });
            const json = await response.json();
            console.log(JSON.stringify(json));
            this.setState({ data: json });
        } catch (error) {
            console.log(error);
        } finally {
            this.setState({ isLoading: false });
        }
    }

    componentDidMount() {
        this.getMovies();
    }

    render() {
        const { data, isLoading } = this.state;

        return (
            <View style={{ flex: 1, padding: 24 }}>
                {isLoading ? <ActivityIndicator /> : (
                    <Text>{data.lastName}, {data.firstName}, {data.emailID}, {data.DOB}</Text>
                )}
            </View>
        );
    }
};