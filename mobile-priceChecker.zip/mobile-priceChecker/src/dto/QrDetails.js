export class QrDetails {
    constructor(szBarcode, pickupStoreID) {
        this.szBarcode = szBarcode;
        this.pickupStoreID = pickupStoreID;
    }
}