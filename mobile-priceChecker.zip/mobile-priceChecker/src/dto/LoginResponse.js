export class LoginResponse {
    constructor(firstName, lastName, id, emailID, registeredDate, DOB) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.emailID = emailID;
        this.registeredDate = registeredDate;
        this.DOB = DOB;
    }
}