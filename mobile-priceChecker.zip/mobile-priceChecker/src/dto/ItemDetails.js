export class ItemDetails {
    constructor(szPOSItemId, itemName, szLineDiscountPercentage,
        szLineDiscountAmount, szQtyDiscountType, szQtyDiscount,
        szDiscountStartDate, szDiscountEndDate, isDiscountRuleActive,
        discountMedia, szDiscountDescription, imageurl, price) {
        this.szPOSItemId = szPOSItemId;
        this.itemName = itemName;
        this.szLineDiscountPercentage = szLineDiscountPercentage;
        this.szLineDiscountAmount = szLineDiscountAmount;
        this.szQtyDiscountType = szQtyDiscountType;
        this.szQtyDiscount = szQtyDiscount;
        this.szDiscountStartDate = szDiscountStartDate;
        this.szDiscountEndDate = szDiscountEndDate;
        this.isDiscountRuleActive = isDiscountRuleActive;
        this.szDiscountDescription = discountMedia;
        this.szQtyDiscount = szDiscountDescription;
        this.imageurl = imageurl;
        this.price = price;
    }
}