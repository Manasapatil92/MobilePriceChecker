export class RegisterRequest {
    constructor(firstName, lastName, emailID, registeredDate, DOB, contactNo, contactNoCountryCode, address, street, city,
        state, country, pin, notificationPref, password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.contactNo = contactNo;
        this.emailID = emailID;
        this.registeredDate = registeredDate;
        this.DOB = DOB;
        this.contactNoCountryCode = contactNoCountryCode;
        this.address = address;
        this.street = street;
        this.city = city;
        this.state = state;
        this.country = country;
        this.pin = pin;
        this.notificationPref = notificationPref;
        this.password = password;
    }
}