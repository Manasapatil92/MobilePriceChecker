export class RegisterResponse {
    constructor(message, code, id) {
        this.message = message;
        this.code = code;
        this.id = id;
    }
}