export class GetItemRequest {
    constructor(clientName, clientId, szBarcode,
        pickupStoreID, onlineChannelID, BUCode) {
        this.clientName = clientName;
        this.clientId = clientId;
        this.szBarcode = szBarcode;
        this.pickupStoreID = pickupStoreID;
        this.onlineChannelID = onlineChannelID;
        this.BUCode = BUCode;
    }
}