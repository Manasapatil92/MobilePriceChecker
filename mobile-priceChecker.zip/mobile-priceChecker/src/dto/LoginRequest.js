export class LoginRequest {
    constructor(userName, passwordB) {
        this.userName = userName;
        this.passwordB = passwordB;
    }
}