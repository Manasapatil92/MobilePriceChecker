import { BarCodeScanner } from 'expo-barcode-scanner';
import React, { useEffect, useState } from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';
import { GetItemRequest } from '../dto/GetItemRequest';
import { QrDetails } from '../dto/QrDetails';

export function ScanPrice(props) {
    const [hasPermission, setHasPermission] = useState(null);
    const [scanned, setScanned] = useState(false);
    const { valueBrand, storeID, clientID } = props.route.params;

    useEffect(() => {
        (async () => {
            const { status } = await BarCodeScanner.requestPermissionsAsync();
            setHasPermission(status === 'granted');
        })();
    }, []);

    const handleBarCodeScanned = ({ type, data }) => {
        setScanned(true);
        console.log("Scanned value: \r\n" + data);
        let item = new QrDetails();
        try {
            item = JSON.parse(data);
        } catch (err) {
            console.log("Something went wrong: " + err);
        }
        let getItemDetails = new GetItemRequest(valueBrand, clientID, item.szBarcode, storeID, "3", "S01");
        console.log("GetItemRequest: "+ getItemDetails);
        props.navigation.navigate("ScanResult", {
            getItemDetails: getItemDetails,
        });
    };


    if (hasPermission === null) {
        return <Text>Requesting for camera permission</Text>;
    }
    if (hasPermission === false) {
        return <Text>No access to camera</Text>;
    }

    return (
        <View style={styles.container}>
            <BarCodeScanner
                onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
                style={StyleSheet.absoluteFillObject}
            />
            {scanned && (
                <Button title={'Tap to Scan Again'} onPress={() => setScanned(false)} />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: .5,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 200
    },
});
