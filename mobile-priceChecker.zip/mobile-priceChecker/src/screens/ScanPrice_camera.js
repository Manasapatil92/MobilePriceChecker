import { BarCodeScanner } from 'expo-barcode-scanner';
import { Camera } from 'expo-camera';
import React, { useEffect, useState } from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';
import { GetItemRequest } from '../dto/GetItemRequest';
import { QrDetails } from '../dto/QrDetails';

export function ScanPrice_camera(props) {
    const [hasPermission, setHasPermission] = useState(null);
    const { valueBrand, storeID } = props.route.params;
    const [type, setType] = useState(Camera.Constants.Type.back);

    useEffect(() => {
      (async () => {
        const { status } = await Camera.requestCameraPermissionsAsync();
        setHasPermission(status === 'granted');
      })();
    }, []);
  
    if (hasPermission === null) {
      return <View />;
    }
    if (hasPermission === false) {
      return <Text>No access to camera</Text>;
    }

    return (
        <View style={styles.container}>
            <Camera type={Camera.Constants.Type.back}>
                barCodeScannerSettings={{
                    barCodeTypes: [BarCodeScanner.Constants.BarCodeType.qr],
                }}
                onBarCodeScanned={({ type, data }) => {
                    console.log("Scanned value: \r\n" + type + "\r\n" + data);
                    let item = new QrDetails();
                    try {
                        item = JSON.parse(data);
                    } catch (err) {
                        console.log("Something went wrong: " + err);
                    }
                    let getItemDetails = new GetItemRequest(valueBrand, 2, item.szBarcode, storeID, "3", "S01");
                    props.navigation.navigate("ScanResult", {
                        getItemDetails: getItemDetails,
                    });
                }}
            </Camera>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: .5,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 200
    },
});
