import {StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    inputContainer: {
        flex: 1,
        justifyContent: 'center',
        marginTop: 50,
        marginBottom: 20,
        marginRight:40,
        marginLeft:10,
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 3,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
      },
    Loginbackground: {
                flex: 1,
                justifyContent: "flex-end",
            },
    logoContainer: {
        flex: 1,
        alignItems: 'center'
    },
    dropdownContainer: {
        flex: 3,
        justifyContent: 'center',
    },
    input: {
        height: 40,
        marginLeft: 30,
        marginRight: 30,
        marginBottom: 10,
        borderWidth: 1,
        borderRadius: 5,
    },
    Logininput: {
        height: 40,
        width: 300,
        paddingHorizontal: 5,
        backgroundColor: 'white',
        marginBottom: 5,
        marginBottom: 20,
        marginRight:90,
      },
    buttonStyle: {
        alignSelf: "center"
    },
    LoginText: {
        fontSize: 10,
        lineHeight: 21,
        fontWeight: 'bold',
        letterSpacing: 0.25,
        color: '#ffb6c1',
      },
    dropdownLabel: {
        marginTop: 20,
        marginBottom: 10,
        fontSize: 20,
        fontWeight: "bold",
    },
    logo: {
        width: 10,
        height: 20,
        resizeMode: 'contain',
        alignItems: 'center',
    },
    button: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 3,
        paddingHorizontal: 3,
        borderRadius: 2,
        elevation: 2,
        backgroundColor:'#4682b4',
        marginBottom: 10,
        marginRight:100,
        marginLeft:100,
      },
});

export default styles;