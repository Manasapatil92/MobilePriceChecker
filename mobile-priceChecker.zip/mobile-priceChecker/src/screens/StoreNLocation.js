import { Picker } from '@react-native-picker/picker';
import React, { Component } from 'react';
import { Button, Image, StyleSheet, Text, View } from 'react-native';

export default class StoreNLocation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            dropdownIndexBrand: 1,
            dropdownValueBrand: 'Saphora',
            storeID: 1002,
            cities: {
                1004: '7Eleven- Vikhroli, Mumbai',
                1005: '7Eleven- Park Street, Kolkata',
                1002: 'Sephora- Kurla, Mumbai',
                1003: 'Sephora- Camp Nou, Barcelona',
                1008: 'Gofirst- Old Trafford, Manchester',
                1009: 'Gofirst- Allianz Arena, Munich'
            }
        };
    }

    renderCities(itemValue, itemIndex) {
        this.setState({ dropdownValueBrand: itemValue });
        if (itemValue == '7Eleven') {
            this.state.dropdownIndexBrand = 2;
        } else if (itemValue == 'Sephora') {
            this.state.dropdownIndexBrand = 1;
        } else if (itemValue == 'Gofirst') {
            this.state.dropdownIndexBrand = 3;
        }
      }

    render() {
        return (

            <View style={styles.inputContainer}>
                <Text style={styles.dropdownLabel}>Please select your favourite retailer:</Text>
                <Picker
                    selectedValue={this.state.dropdownValueBrand}
                    style={styles.Picker}
                    onValueChange={(itemValue, itemIndex) => this.renderCities(itemValue, itemIndex)}
                >
                    <Picker.Item label="Sephora" value="Sephora" />
                    <Picker.Item label="Go First" value="Gofirst" />
                    <Picker.Item label="7Eleven" value="7Eleven" />
                </Picker>

                <Text style={styles.dropdownLabel}>Please select the store:</Text>

                <Picker
                    selectedValue={this.state.storeID}
                    style={styles.Picker}
                    onValueChange={(itemValue, itemIndex) => {
                        this.setState({ storeID: itemValue });  
                    }}
                >
                    {Object.keys(this.state.cities).map((key) => {
                        return (<Picker.Item label={this.state.cities[key]} value={key} key={key} />)
                    })}
                </Picker>

                <View style={styles.button}>
                    <Button title="Next" color="white" onPress={() => {
                        console.log(this.state.dropdownIndexBrand + ' ' + this.state.dropdownValueBrand + ' ' + this.state.storeID);
                        this.props.navigation.navigate("ScanPrice", {
                            valueBrand: this.state.dropdownValueBrand,
                            storeID: this.state.storeID,
                            clientID: this.state.dropdownIndexBrand,
                        })
                    }}></Button>
                </View>
            </View>

        );
    }
}


const styles = StyleSheet.create({
    inputContainer: {
        flex: 1,
        justifyContent: 'center',
        marginTop: 5,
        marginBottom: 80,
        marginRight: 40,
        marginLeft: 10,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 3,
        }
    },

    logoContainer: {
        flex: 1,
        alignItems: 'center'
    },
    button: {
        alignItems: 'center',
        paddingVertical: 3,
        paddingHorizontal: 3,
        borderRadius: 2,
        elevation: 3,
        backgroundColor: '#4682b4',
        marginBottom: 2,
        marginRight: 100,
        marginLeft: 10,
    },
    text: {
        fontSize: 15,
        lineHeight: 21,
        fontWeight: 'bold',
        letterSpacing: 0.25,
        color: '#483d8b',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 3,
        },
    },
    pickerStyle: {
        height: 150,
        width: "80%",
        color: '#344953',
        justifyContent: 'center',
    },

    dropdownLabel: {
        fontSize: 20,
        lineHeight: 21,
        fontWeight: 'bold',
        letterSpacing: 0.25,
        color: '#00008b',
    },
    logo: {
        width: 10,
        height: 20,
        resizeMode: 'contain',
        alignItems: 'center',
    },
});
