import React, { Component } from 'react';
import { Button, Image, StyleSheet, Text, View } from 'react-native';
import AnimatedLoader from "react-native-animated-loader";
import { Rows, Table } from 'react-native-table-component';
import { ItemDetails } from '../dto/ItemDetails';

export default class ScanResult extends Component {
    // _isMounted = false;
    constructor(props) {
        super(props);
        this.state = {
            getItemDetails: this.props.route.params.getItemDetails,
            data: ItemDetails,
            genInfoArray1: [],
            priceArray1: [],
            isLoading: true,
            isItemFound: true,
            visible: false,
            isApiCalled: false
        };
    }

    /* componentDidMount() {
         this._isMounted = true;
         //this.getPriceDetails();
     }
 
     componentWillUnmount() {
         this._isMounted = false;
     }*/

    render() {
        if (this.state.isApiCalled == false) {
            this.getPriceDetails();
        }
        if (this.state.isLoading == true) {
            return (
                <AnimatedLoader
                    visible={true}
                    overlayColor="rgba(255,255,255,0.75)"
                    source={require("../resources/loader.json")}
                    animationStyle={styles.lottie}
                    speed={1}
                >
                    <Text>Doing something...</Text>
                </AnimatedLoader>
            );
        } else {
            if (this.state.isItemFound == true) {
                return (
                    <View style={styles.container}>
                        <Image source={{ uri: this.state.data.imageurl }} style={styles.photo} />
                        <View style={styles.priceData}>
                            <Text style={styles.textHead}>General Info</Text>
                            <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                                <Rows data={this.state.genInfoArray1} textStyle={styles.text} />
                            </Table>
                            <Text style={styles.textHead}>Price Info</Text>
                            <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                                <Rows data={this.state.priceArray1} textStyle={styles.text} />
                            </Table>
                        </View>
                        <View style={styles.buttonContainer}>
                            <Button title="Scan Another Item" onPress={() => {
                                this.props.navigation.navigate("ScanPrice", {
                                    valueBrand: this.state.getItemDetails.clientName,
                                    storeID: this.state.getItemDetails.clientId,
                                })
                            }} />
                        </View>
                    </View>
                );
            } else {
                return (
                    <View style={styles.container}>
                        <Image source={require("../resources/no_items_found.png")} style={styles.photoNotFound} />
                        <View style={styles.button}>
                            <Button title="Try Again" color="white" onPress={() => {
                                this.props.navigation.navigate("StoreNLocation")
                            }} />
                        </View>
                    </View>
                );
            }
        }

    }

    async getPriceDetails() {
        try {
            // if (this._isMounted == true) {
            console.log(JSON.stringify({
                "clientName": this.state.getItemDetails.clientName,
                "clientId": this.state.getItemDetails.clientId,
                "szBarcode": this.state.getItemDetails.szBarcode,
                "pickupStoreID": parseInt(this.state.getItemDetails.pickupStoreID),
                "onlineChannelID": this.state.getItemDetails.onlineChannelID,
                "BUCode": this.state.getItemDetails.BUCode
            }));

            const response = await fetch('http://mobilepricechecker-sapi.us-e2.cloudhub.io/api/getItemDiscount', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'client_id': "1",
                    'client_secret': "7"
                },
                body: JSON.stringify({
                    "clientName": this.state.getItemDetails.clientName,
                    "clientId": this.state.getItemDetails.clientId,
                    "szBarcode": this.state.getItemDetails.szBarcode,
                    "pickupStoreID": parseInt(this.state.getItemDetails.pickupStoreID),
                    "onlineChannelID": this.state.getItemDetails.onlineChannelID,
                    "BUCode": this.state.getItemDetails.BUCode
                })
            });
            const json = await response.json();
            console.log(JSON.stringify(json));
            this.setState({ data: json });
            console.log("data after API call: " + JSON.stringify(this.state.data));
            if (this.state.data.szPOSItemId != null) {
                let priceAfterDisc = this.state.data.price;
                if (this.state.data.szLineDiscountAmount != null) {
                    priceAfterDisc = priceAfterDisc - this.state.data.szLineDiscountAmount;
                } else if (this.state.data.szLineDiscountPercentage != null) {
                    priceAfterDisc = priceAfterDisc - (priceAfterDisc * this.state.data.szLineDiscountPercentage / 100);
                }
                let expDate = new Date(new String(this.state.data.szDiscountEndDate));

                this.state.genInfoArray1 = [
                    ['Product Id', this.state.data.szPOSItemId],
                    ['Name', this.state.data.itemName],
                    ['Additional Informtion', this.state.data.discountMedia],
                    ['Availability', 'In Stock']
                ];
                this.state.priceArray1 = [
                    ['Price', this.state.data.price + ' INR'],
                    ['Item Discount', this.state.data.szDiscountDescription],
                    ['Price after Discount', priceAfterDisc +' INR'],
                    ['Offer Valid till', expDate.toDateString() ]
                ];
                //this.props.navigation.navigate("StoreNLocation");
                //this.state.isMount = false;

            }
            else {
                this.state.isItemFound = false;
            }
            /*  } else {
                  console.log('isMount is false');
              }*/
        } catch (error) {
            console.log(error);
        } finally {
            this.setState({ isLoading: false, visible: false, isApiCalled: true });
        }
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 18,
        paddingTop: 35,
        backgroundColor: '#ffffff',
        justifyContent: 'center',
    },
    photo: {
        flex: 1,
        width: 200,
        height: 200,
        alignSelf: "center"
    },
    priceData: {
        flex: 2,
        margin: 20,
    },
    text: {
        margin: 6,
        width: 'auto',
    },
    textHead: {
        alignSelf: "center",
        fontWeight: "bold",
        fontSize: 20,
        margin: 10,
        alignContent: "center",

    },
    photoNotFound: {
        flex: 2,
        width: 800,
        height: 700,
        marginBottom: 70,
        marginTop: 70,
        alignSelf: "center",
        justifyContent: 'center',
    },
    lottie: {
        width: 100,
        height: 100
    },
    button: {
        alignItems: 'center',
        paddingVertical: 3,
        paddingHorizontal: 3,
        borderRadius: 2,
        elevation: 3,
        backgroundColor: '#4682b4',
        marginBottom: 10,
        marginRight: 90,
        marginLeft: 90,
    },
});
