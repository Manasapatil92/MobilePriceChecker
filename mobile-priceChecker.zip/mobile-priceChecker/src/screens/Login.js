import React, { Component } from 'react';
import { Alert, Button, ImageBackground, StyleSheet, Picker, TextInput, View, Text } from 'react-native';
import { LoginResponse } from '../dto/LoginResponse';
//import {styles} from '../screens/styles.js';

export default class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
            username: null,
            password: null,
            data: LoginResponse,
            isLoading: true
        };
    }


    clickme = () => {
        console.log("Username: " + this.state.username);
        console.log("Password: " + this.state.password);
        this.login();
    }

    clickToRegister = () => {
        console.log("Redirecting register page...");
        this.props.navigation.navigate("Register");
    }

    render() {
        return (
            <ImageBackground resizeMode="cover" source={require("../resources/dn-theme.png")} style={styles.background} >
                <View style={styles.container}>
                    <TextInput
                        style={styles.Logininput}
                        placeholder="EmailId"
                        onChangeText={(text) => this.setState({ username: text })}
                    />
                    <TextInput
                        style={styles.Logininput}
                        placeholder="Password"
                        secureTextEntry={true}
                        onChangeText={(text) => this.setState({ password: text })}
                    />
                    <View style={styles.button}>
                        <Button title="Login"  color="white" onPress={this.clickme}></Button>
                    </View>
                    <View style={styles.button}>
                        <Button title="Not an user? Register" color="white" onPress={this.clickToRegister}></Button>
                    </View>
                </View>
            </ImageBackground>
        );
    }

    async login() {
        try {
            const response = await fetch('http://mobilepricechecker-sapi.us-e2.cloudhub.io/api/login', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'client_id': "1",
                    'client_secret': "7"
                },
                body: JSON.stringify({
                    "userName": this.state.username,
                    "password": this.state.password
                })
            });
            const json = await response.json();
            console.log(JSON.stringify(json));
            this.setState({ data: json });
            console.log("data after API call: " + JSON.stringify(this.state.data));
            if (this.state.data.id != null) {
                this.props.navigation.navigate("StoreNLocation");
            }
            else {
                Alert.alert("Error!", "Invalid Credentials!")
            }
        } catch (error) {
            console.log(error);
        } finally {
            this.setState({ isLoading: false });
        }
    }
}


const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: "flex-end",
    },
    container: {
        flex: 1,
        justifyContent: 'center',
        marginTop: 50,
        marginBottom: 20,
        marginRight:40,
        marginLeft:10,
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 3,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
      },
      Logininput: {
        height: 30,
        width: 300,
        justifyContent: 'center',
        paddingHorizontal: 10,
        backgroundColor: '#e6e6fa',
        marginBottom: 5,
        marginBottom: 10,
        marginRight:50,
        marginLeft:50,
        borderColor:'#778899',
      },
      button: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 3,
        paddingHorizontal: 3,
        borderRadius: 2,
        elevation: 2,
        backgroundColor:'#4682b4',
        marginBottom: 20,
        marginRight:100,
        marginLeft:100,
      },
      text: {
        fontSize: 15,
        lineHeight: 21,
        fontWeight: 'bold',
        letterSpacing: 0.25,
        marginLeft:20,
        color: '#ff6347',
      },
});
