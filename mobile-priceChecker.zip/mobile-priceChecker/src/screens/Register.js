import React, { Component } from 'react';
import { Alert, Button, ImageBackground, ScrollView, StyleSheet,Picker, TextInput, View } from 'react-native';
import { RegisterResponse } from '../dto/RegisterResponse';

export default class Register extends Component {

    constructor(props) {
        super(props);
        this.state = {
            firstName: null,
            lastName: null,
            emailID: null,
            DOB: null,
            contactNo: Number,
            contactNoCountryCode: Number,
            address: null,
            street: null,
            city: null,
            state: null,
            country: null,
            pin: Number,
            notificationPref: null,
            password: null,
           // data: RegisterResponse,
            //isLoading: true
        };
    }


    clickme = () => {
        this.register();
    }

    clickToBack = () => {
        this.props.navigation.navigate("Login");
    }

    render() {
        return (
            //<ImageBackground resizeMode="cover" source={require("../resources/dn-theme.png")} style={styles.background} >
                <ScrollView contentContainerStyle={styles.inputContainer}>
                    <TextInput
                        style={styles.input}
                        placeholder="FirstName"

                        onChangeText={(text) => this.setState({ firstName: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="LastName"
                        onChangeText={(text) => this.setState({ lastName: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Email"

                        onChangeText={(text) => this.setState({ emailID: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="DOB"
                        onChangeText={(text) => this.setState({ DOB: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Contact Number"
                        keyboardType='numeric'
                        onChangeText={(Number) => this.setState({ contactNo: Number })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Country"

                        onChangeText={(text) => this.setState({ country: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Country Code"
                        keyboardType='numeric'
                        onChangeText={(Number) => this.setState({ contactNoCountryCode: Number })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Address"

                        onChangeText={(text) => this.setState({ address: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Street"
                        onChangeText={(text) => this.setState({ street: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="City"

                        onChangeText={(text) => this.setState({ city: text })}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="State"
                        onChangeText={(text) => this.setState({ state: text })}
                    />
                   
                    <TextInput
                        style={styles.input}
                        placeholder="Pin"
                        keyboardType='numeric'
                        onChangeText={(Number) => this.setState({ pin: Number })}
                    />
                   
                    <TextInput
                        style={styles.input}
                        placeholder="Password"
                        secureTextEntry={true}
                        onChangeText={(text) => this.setState({ password: text })}
                    />
                     {/* <Picker
                        selectedValue={this.state.notificationPref}
                        style={styles.pickerStyle}
                        onValueChange={(itemValue, itemIndex) => this.setState({ notificationPref: itemValue })}
                    >
                        <Picker.Item label="DND" value="DND" />
                        <Picker.Item label="Email" value="Email" />
                        <Picker.Item label="SMS" value="SMS" />
                    </Picker> */}
                    <TextInput
                        style={styles.input}
                        placeholder="Notification preference"
                        onChangeText={(text) => this.setState({ notificationPref: text })}
                    />
                    <View style={styles.button}>
                        <Button title="Register" color="white" onPress={this.clickme}></Button>
                    </View>
                    <View style={styles.button}>
                        <Button title="Back" color="white" onPress={this.clickToBack}></Button>
                    </View>
                </ScrollView>
           // </ImageBackground>
        );
    }

    async register() {
        console.log(JSON.stringify({
            "firstName": this.state.firstName,
            "lastName": this.state.lastName,
            "email": this.state.emailID,
            "dob": this.state.DOB,
            "contactNo": parseInt(this.state.contactNo),
            "contactNoCountryCode": parseInt(this.state.contactNoCountryCode),
            "address": this.state.address,
            "street": this.state.street,
            "city": this.state.city,
            "state": this.state.state,
            "country": this.state.country,
            "pin": parseInt(this.state.pin),
            "notificationPref": this.state.notificationPref,
            "password": this.state.password
        }));
        try {
            const response = await fetch('http://mobilepricechecker-sapi.us-e2.cloudhub.io/api/register', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'client_id': "1",
                    'client_secret': "7"
                },
                body: JSON.stringify({
                    "firstName": this.state.firstName,
                    "lastName": this.state.lastName,
                    "email": this.state.emailID,
                    "dob": this.state.DOB,
                    "contactNo": parseInt(this.state.contactNo),
                    "contactNoCountryCode": parseInt(this.state.contactNoCountryCode),
                    "address": this.state.address,
                    "street": this.state.street,
                    "city": this.state.city,
                    "state": this.state.state,
                    "country": this.state.country,
                    "pin": parseInt(this.state.pin),
                    "notificationPref": this.state.notificationPref,
                    "password": this.state.password
                })
            });
            const json = await response.json();
            console.log(JSON.stringify(json));
            //this.setState({ data: json });
            let data = new RegisterResponse();
            data = json;
            console.log("data after API call: " + JSON.stringify(data));
            if (data.id != null) {
                Alert.alert("Registered successfully! Please login now!");
                this.props.navigation.navigate("Login");
            }
            else {
                Alert.alert("Error!", "Please try again later!");
            }
        } catch (error) {
            console.log(error);
        } finally {
           // this.setState({ isLoading: false });
        }
    }
}


const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: "flex-end",
    },
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    input: {
        height: 30,
        width: 300,
        justifyContent: 'center',
        paddingHorizontal: 10,
        backgroundColor: '#e6e6fa',
        marginBottom: 5,
        marginBottom: 10,
        marginRight:50,
        marginLeft:50,
        borderColor:'#778899',
        
      },
      inputContainer: {
        flex: 1,
        justifyContent: 'center',
        marginTop: 10,
        marginBottom: 20,
        marginRight:10,
        marginLeft:10,
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 3,
        }
    },
      button: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 3,
        paddingHorizontal: 3,
        borderRadius: 2,
        elevation: 2,
        backgroundColor:'#4682b4',
        marginBottom: 10,
        marginRight:100,
        marginLeft:100,
      },
      pickerStyle:{ 
        height: 30,
        width: 300,
        justifyContent: 'center',
        paddingHorizontal: 5,
        backgroundColor: '#e6e6fa',
        marginBottom: 5,
        marginBottom: 20,
        marginRight:50,
        marginLeft:50,
        borderColor:'#778899', 
       fontSize: 10,
       fontFamily:'arial',
        justifyContent: 'center',  
    },
});
