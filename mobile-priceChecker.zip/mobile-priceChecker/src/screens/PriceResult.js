import React, { Component } from 'react';
import { Button, Image, StyleSheet, Text, View } from 'react-native';
import { Rows, Table } from 'react-native-table-component';

export default class PriceResult extends Component {
    constructor(props) {
        super(props);
        this.state = {
            qrCode: this.props.route.params.qrData,
            genInfoArray1: [
                ['Product Id', 'ALTR1252'],
                ['Name', 'T-Shirt Round Neck'],
                ['Brand', 'Levi`s'],
                ['Size', 'L'],
                ['Color', 'Black'],
                ['Store', 'H&M, Mumbai']
            ],
            priceArray1: [
                ['Price', '599 INR'],
                ['Item Discount- 10%', '60 INR'],
                ['Membership Discount- Gold Cust', '60 INR'],
                ['Buyback points', '0 INR'],
                ['Final Price - Incl Taxes', '479 INR']
            ],
            genInfoArray2: [
                ['Product Id', 'CR082829'],
                ['Name', 'Samsung S20 Ultra 256 GB'],
                ['Brand', 'Samsung'],
                ['Type', 'Smartphone'],
                ['Color', 'Black'],
                ['Store', 'Croma, Mumbai']
            ],
            priceArray2: [
                ['Price', '85999 INR'],
                ['Item Discount- new_year_sale', '8600 INR'],
                ['Membership Discount-', '0 INR'],
                ['Buyback points- 80 points available)', '40 INR'],
                ['Final Price - Incl Taxes', '77360 INR']
            ]
        };
    }

    render() {
        console.log("qrCode " + this.state.qrCode);
        if (this.state.qrCode == 1) {
            return (
                <View style={styles.container}>
                    <Image source={require("../resources/levis.png")} style={styles.photo} />
                    <View style={styles.priceData}>
                        <Text style={styles.textHead}>General Info</Text>
                        <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                            <Rows data={this.state.genInfoArray1} textStyle={styles.text} />
                        </Table>
                        <Text style={styles.textHead}>Price Info</Text>
                        <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                            <Rows data={this.state.priceArray1} textStyle={styles.text} />
                        </Table>
                    </View>
                </View>
            );
        } else if (this.state.qrCode == 2) {
            return (
                <View style={styles.container}>
                    <Image source={require("../resources/s20.png")} style={styles.photo} />
                    <View style={styles.priceData}>
                        <Text style={styles.textHead}>General Info</Text>
                        <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                            <Rows data={this.state.genInfoArray2} textStyle={styles.text} />
                        </Table>
                        <Text style={styles.textHead}>Price Info</Text>
                        <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
                            <Rows data={this.state.priceArray2} textStyle={styles.text} />
                        </Table>
                    </View>
                </View>
            );
        } else {
            return (
                <View style={styles.container}>
                    <Image source={require("../resources/no_items_found.png")} style={styles.photoNotFound} />
                    <View style={styles.buttonContainer}>
                        <Button title="Try Again" onPress={() => { this.props.navigation.navigate("ScanPrice") }} />
                    </View>
                </View>
            )

        }

    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    photo: {
        flex: 1,
        width: 200,
        height: 200,
        alignSelf: "center"
    },
    priceData: {
        flex: 2,
        margin: 20,
    },
    text: { margin: 6 },
    textHead: {
        alignSelf: "center",
        fontWeight: "bold",
        fontSize: 20,
        margin: 30,
    },
    photoNotFound: {
        flex: 2,
        width: 400,
        height: 400,
        alignSelf: "center"
    },
    buttonContainer: {
        flex: 1,
        margin: 20,
    },
});
